Prebuilt boot images for JingPad C1 firmware 1.0.0002.011 (S813_JingPad_C1_1.0.0002.011_user_202111011157)
Built by tools/make_magisk_boot.sh from https://github.com/c12n/jingpad-lineageos

ONLY for tablets whose boot build matches exactly:
  adb shell getprop ro.bootimage.build.fingerprint
  -> JingPad/ud710_3h10u_native/ud710_3h10u:10/QP1A.190711.020/44110:user/release-keys
(This stays the same after flashing a LineageOS GSI.)

boot-magisk-v31.0-C1-1.0.0002.011-signed.img
    Stock boot patched with Magisk v31.0 (official boot_patch.sh, flags the app
    uses on this tablet: KEEPVERITY=true, KEEPFORCEENCRYPT=true), re-signed with
    the AOSP test key. Flash with flash/flash_magisk.sh (writes images/vbmeta-sign-root.img).
    Install the matching app: https://github.com/topjohnwu/Magisk/releases/tag/v31.0
    Patched on a PC, so no "pre-init" partition is recorded: modules that ship
    their own SELinux rules may need an app-patched boot instead.

boot-stock-C1-1.0.0002.011.img
    Untouched stock boot, to un-root: flash/flash_magisk.sh --unroot <this file>

Keep the .fingerprint files next to the images; the flash script checks them.
