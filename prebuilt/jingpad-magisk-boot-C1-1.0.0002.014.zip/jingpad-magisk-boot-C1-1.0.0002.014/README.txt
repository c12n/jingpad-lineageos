Prebuilt boot images for JingPad C1 firmware 1.0.0002.014 (userdebug, Apr 2022)
=============================================================================
ONLY for tablets whose boot build matches exactly:
  adb shell getprop ro.bootimage.build.fingerprint
  -> JingPad/ud710_3h10u_native/ud710_3h10u:10/QP1A.190711.020/14011:userdebug/test-keys
(This stays the same after flashing a LineageOS GSI, because the GSI does not
replace boot.) Any other build: patch your own boot.img - see the kit README.

boot-magisk-v31.0-C1-1.0.0002.014-signed.img
    Stock boot patched with Magisk v31.0 (official boot_patch.sh, same flags the
    app uses on this tablet: KEEPVERITY=true, KEEPFORCEENCRYPT=true), then
    re-signed with the AOSP test key. Flash with flash/flash_magisk.sh, which
    also writes images/vbmeta-sign-root.img. Install the matching Magisk app:
    https://github.com/topjohnwu/Magisk/releases/tag/v31.0
    Patched on a PC, so it has no "pre-init" partition recorded: modules that
    ship their own SELinux rules may need an app-patched boot instead.

boot-stock-C1-1.0.0002.014.img
    Untouched stock boot, to un-root: flash/flash_magisk.sh --unroot <this file>

Put the .fingerprint file next to the image; the flash script checks it.
